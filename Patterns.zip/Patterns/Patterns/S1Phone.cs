﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns
{
    class S1Phone : Phone
    {
        public S1Phone(){}

        public override void asamblePhone(string line)
        {
            Console.WriteLine(line + " a inceput asamblarea modelului S1!");
        }
    }
}
