﻿
namespace Patterns
{
    class S2Phone : Phone
    {
        public S2Phone(){}

        public override void asamblePhone(string line)
        {
            Console.WriteLine(line + " a inceput asamblarea modelului S2!");
        }
    }
}
