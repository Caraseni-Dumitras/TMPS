﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns
{
    class Singleton
    {
        private static Singleton _instance;
        private static object locker = new object();
        public static void Print()
        {
            Console.WriteLine("Hello");
        }

        public void Move(int x)
        {
            if (x % 2 == 0)
            {
                Console.WriteLine("Jucatorul 1 a efectuat o mutare!");
            }
            else
            {
                Console.WriteLine("Jucatorul 2 a efectuat o mutare!");
            }
        }

        private Singleton() 
        {
            Console.WriteLine("Tabla a fost creata");
        }

        public static Singleton GetInstance()
        {
            if (_instance == null)
            {
                lock (locker)
                {
                    if (_instance == null)
                    {
                        _instance = new Singleton();
                    }
                }
            }
            return _instance;
        }
    }
}

/* 
            int x = 0;

            while(x <= 5)
            {
                Singleton.GetInstance().Move(x);
                x++;
            }

            Console.WriteLine("Test Tasks!");

            Task.Run(() => Singleton.GetInstance().Move(1));
            Task.Run(() => Singleton.GetInstance().Move(2));
            Console.ReadLine();
            */