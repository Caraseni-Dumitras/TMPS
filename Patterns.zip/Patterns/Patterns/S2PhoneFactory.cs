﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Patterns
{
    class S2PhoneFactory : PhoneFactory
    {
        public override Phone Create()
        {
            S2Phone phone = new S2Phone();
            //logica complicata care ar fi trebuit sa fie in constructor
            return phone;
        }
    }
}
