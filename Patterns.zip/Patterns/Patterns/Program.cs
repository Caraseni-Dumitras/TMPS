﻿

namespace Patterns
{
    class Program
    {
        static void Main(string[] args)
        {
            PhoneFactory factory = new S1PhoneFactory();

            Phone line1 = factory.Create();
            Phone line2 = factory.Create();
            Phone line3 = factory.Create();
            // . . . . . . . . . . . . . . 
            Phone line99 = factory.Create();

            line1.asamblePhone("Linia 1");
            line2.asamblePhone("Linia 2");
            line3.asamblePhone("Linia 3");
            // . . . . . . . . . . . . . . 
            line99.asamblePhone("Linia 999");
        }
    }
}