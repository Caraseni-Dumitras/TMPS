﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Styles
{
    internal class Poly: Style
    {
        public Poly()
        {
            Material = "Plastic";
        }
        public override void Style_Info()
        {
            Console.WriteLine($"Poly style is using {Material} for furniture!");
        }
    }
}
