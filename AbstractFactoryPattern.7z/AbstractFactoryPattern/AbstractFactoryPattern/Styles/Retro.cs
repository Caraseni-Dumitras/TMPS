﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Styles
{
    internal class Retro : Style
    {
        public Retro()
        {
            Material = "Wood";
        }
        public override void Style_Info()
        {
            Console.WriteLine($"Retro style is using {Material} for furniture!");
        }
    }
}
