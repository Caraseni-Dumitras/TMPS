﻿using AbstractFactory.Factories;
using AbstractFactory.Furnituries;
using AbstractFactory.Styles;

namespace AbstractFactoryPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            IFactoryProduct factory = new PolyTablesFactory(); //Second Factory is "RetroStorageFactory"!

            Furniture furniture = factory.CreateFurniture();
            Style style = factory.CreateStyle();

            style.Style_Info();
            furniture.Furniture_Info();

        }
    }
}

